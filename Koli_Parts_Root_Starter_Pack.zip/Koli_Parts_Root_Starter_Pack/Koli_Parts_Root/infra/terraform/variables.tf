variable "project_id" { type = string }
variable "region" { type = string, default = "europe-west1" }
variable "environment" { type = string, default = "staging" }
